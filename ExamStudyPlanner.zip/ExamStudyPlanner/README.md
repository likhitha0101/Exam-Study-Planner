# 📚 Exam Study Planner with Fatigue Optimization

A C++ console application that uses **3-D Dynamic Programming** to compute the
optimal study schedule for multiple exam subjects, accounting for mental fatigue
that degrades efficiency over time.

---

## Table of Contents
1. [Problem Statement](#problem-statement)
2. [Architecture](#architecture)
3. [DP Formulation](#dp-formulation)
4. [Fatigue Model](#fatigue-model)
5. [Why DP over Greedy](#why-dp-over-greedy)
6. [Build & Run](#build--run)
7. [Sample Output](#sample-output)
8. [Project Structure](#project-structure)

---

## Problem Statement

Given:
* A set of **N subjects**, each with:
  * `study_time`    — 30-minute units of study required
  * `importance`    — base marks score (1–100)
  * `fatigue_impact`— mental drain imposed (1–10)
* A **total time budget** T (in 30-min units)
* Optional **breaks** (cost: 1 unit, recovery: −3 fatigue)

**Goal:** Choose which subjects to study (and when to insert breaks) to
**maximise total effective score**, where effective score is reduced by fatigue.

---

## Architecture

```
ExamStudyPlanner/
├── include/
│   ├── Subject.h      ← data model (name, time, importance, fatigue_impact)
│   └── Planner.h      ← 3-D DP scheduler; fatigue & break model
├── src/
│   ├── Subject.cpp
│   ├── Planner.cpp    ← core DP fill + backtracking
│   └── main.cpp       ← interactive CLI + --demo mode
├── Makefile
└── README.md
```

**Classes:**

| Class | Responsibility |
|---|---|
| `Subject` | Holds subject data; pretty-prints itself |
| `Planner` | Manages the DP table, solves, back-tracks, and reports results |
| `ScheduleEntry` | Lightweight struct for one scheduled slot (study or break) |

---

## DP Formulation

### State

```
dp[i][t][f]  =  maximum effective score achievable
                considering subjects 0 .. i-1,
                having consumed exactly t time-units,
                with cumulative fatigue level f.
```

* `i  ∈ [0 .. N]`           — subject index
* `t  ∈ [0 .. T]`           — time units consumed
* `f  ∈ [0 .. MAX_FATIGUE]` — fatigue level (capped at 12)

### Transitions

```
// SKIP subject i
dp[i+1][t][f]  ←  dp[i][t][f]

// STUDY subject i  (requires t ≥ study_time)
eff_score  = importance_i × efficiency(f)
new_f      = min(f + fatigue_impact_i, MAX_FATIGUE)
dp[i+1][t][new_f]  ←  dp[i][t - study_time][f] + eff_score

// BREAK then STUDY  (requires t ≥ study_time + BREAK_COST)
f_rb       = max(0, f - BREAK_RECOVERY)
eff_score  = importance_i × efficiency(f_rb)
new_f      = min(f_rb + fatigue_impact_i, MAX_FATIGUE)
dp[i+1][t - BREAK_COST][new_f]  ←  dp[i][t - study_time - BREAK_COST][f] + eff_score
```

### Complexity

| Dimension | Range |
|---|---|
| Subjects N | ≤ 10 |
| Time T | ≤ 48 units (24 hours) |
| Fatigue F | ≤ 12 |

**Time:**  O(N × T × F × 3) ≈ 10 × 48 × 12 × 3 = **17 280 operations** — instant.  
**Space:** O(N × T × F) ≈ **6 912 cells**.

---

## Fatigue Model

```
efficiency(f) = max(0.0,  1.0 − f × 0.08)
```

| Fatigue | Efficiency |
|---|---|
| 0 | 100 % |
| 2 | 84 % |
| 4 | 68 % |
| 6 | 52 % |
| 8 | 36 % |
| 10 | 20 % |
| 12 | 4 % |

A **break** costs `1` time-unit and subtracts `3` fatigue units, making it
worthwhile when the next subject has high `importance` and the student is
already at high fatigue.

---

## Why DP over Greedy

A greedy heuristic (e.g., highest `importance / study_time` first) fails because:

1. **Order matters** — studying a high-impact, high-drain subject first
   lowers efficiency for every subsequent subject.
2. **Breaks are non-obvious** — inserting a break is beneficial only if the
   efficiency gain from recovered fatigue outweighs the lost time-unit.
3. **Global optimum** — DP evaluates *all feasible orderings* simultaneously
   through the fatigue dimension and guarantees the globally optimal score.

**Counter-example:**

| Subject | Importance | Study time | Fatigue impact |
|---|---|---|---|
| Maths | 90 | 2 | 8 |
| History | 80 | 2 | 2 |

Total time = 4. Greedy picks Maths first (higher importance):
* Maths at f=0  → 90 × 1.00 = 90
* History at f=8 → 80 × 0.36 = 28.8  → **total 118.8**

DP finds: History first:
* History at f=0 → 80 × 1.00 = 80
* Maths at f=2  → 90 × 0.84 = 75.6  → **total 155.6** ✓

---

## Build & Run

### Requirements
* g++ ≥ 7 with C++17 support

### Compile
```bash
make          # builds ./ExamStudyPlanner
```

### Run (interactive)
```bash
make run
# or
./ExamStudyPlanner
```

### Run demo (pre-loaded scenario)
```bash
make demo
# or
./ExamStudyPlanner --demo
```

### Clean
```bash
make clean
```

---

## Sample Output (demo mode)

```
OPTIMAL STUDY SCHEDULE
-----------------------------------------------------------------
Session                Time      Fatigue       Effic.    Score
-----------------------------------------------------------------
English                1u (30m)  0 → 2         100%      50.0
Digital Circuits       2u (60m)  2 → 7         84%       58.8
-- Break --            1u (30m)  7 → 4         —         —
Data Structures        3u (90m)  4 → 11        68%       61.2
OS Concepts            3u (90m)  11 → 12       12%       9.6
-----------------------------------------------------------------
TOTAL                  10u (300m)                        179.6

★  TOTAL ACHIEVABLE SCORE : 179.60 / 375.00
```

---

## Project Structure

```
ExamStudyPlanner/
├── include/
│   ├── Subject.h          ← Subject class declaration + documentation
│   └── Planner.h          ← Planner class, DP state definition, constants
├── src/
│   ├── Subject.cpp        ← Subject constructor + display
│   ├── Planner.cpp        ← DP solve(), backtrack(), printResults()
│   └── main.cpp           ← CLI entry point (interactive + demo)
├── Makefile
└── README.md
```

---

> **Author:** Generated for academic / learning purposes.  
> **License:** MIT — free to use and modify.
