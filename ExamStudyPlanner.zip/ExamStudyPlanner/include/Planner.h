#pragma once
#include "Subject.h"
#include <vector>
#include <string>

/**
 * ============================================================
 *  Planner.h  —  DP-based study scheduler with fatigue model
 * ============================================================
 *
 *  ── DP STATE ────────────────────────────────────────────────
 *
 *  dp[i][t][f]  =  maximum effective score achievable by
 *                  considering subjects 0..i-1,
 *                  using exactly t time-units,
 *                  with a current fatigue level of f.
 *
 *  i  ∈ [0 .. N]           N = number of subjects
 *  t  ∈ [0 .. T]           T = total available time-units
 *  f  ∈ [0 .. MAX_FATIGUE] capped at MAX_FATIGUE
 *
 *  ── FATIGUE MODEL ───────────────────────────────────────────
 *
 *  efficiency(f) = max(0.0, 1.0 - f * FATIGUE_DECAY)
 *
 *  Where FATIGUE_DECAY = 0.08 (8 % drop per fatigue unit).
 *  So at f=0 → 100 %, f=5 → 60 %, f=10 → 20 %, f≥13 → 0 %.
 *
 *  effective_score(subject, f) = subject.importance
 *                                 * efficiency(f)
 *
 *  A 10-minute BREAK costs 1 time-unit and reduces fatigue
 *  by BREAK_RECOVERY (= 3 units), letting students restore
 *  efficiency mid-session.
 *
 *  ── TRANSITION ──────────────────────────────────────────────
 *
 *  For each subject i with study_time s and fatigue_impact d:
 *
 *    SKIP subject i:
 *      dp[i+1][t][f] = dp[i][t][f]
 *
 *    STUDY subject i (if t >= s):
 *      score = importance_i * efficiency(f)
 *      dp[i+1][t][f] = max(dp[i+1][t][f],
 *                          dp[i][t-s][f] + score)
 *      new_fatigue = min(f + d, MAX_FATIGUE)
 *
 *    BREAK (optional, costs 1 time-unit):
 *      dp[i][t][f] = dp[i][t-1][min(0, f-BREAK_RECOVERY)]
 *
 *  ── WHY DP OVER GREEDY ──────────────────────────────────────
 *
 *  A greedy approach (e.g. highest importance-per-unit first)
 *  ignores the compounding fatigue state.  Studying a high-
 *  importance but high-fatigue subject early could depress
 *  efficiency for all subsequent subjects, yielding a lower
 *  total than a different ordering.  DP exhaustively evaluates
 *  ALL feasible subject/break combinations and guarantees the
 *  globally optimal schedule.
 */

struct ScheduleEntry {
    std::string label;   // subject name or "Break"
    int         units;   // time-units consumed
    double      score;   // effective score gained (0 for breaks)
    int         fatigue_before;
    int         fatigue_after;
};

class Planner {
public:
    static constexpr double FATIGUE_DECAY  = 0.08;
    static constexpr int    MAX_FATIGUE    = 12;
    static constexpr int    BREAK_RECOVERY = 3;
    static constexpr int    BREAK_COST     = 1;   // time-units

    explicit Planner(int total_time_units);

    void addSubject(const Subject& s);
    void solve(bool allow_breaks = true);
    void printResults() const;
    void printDPTable()  const;   // debug / documentation aid

    // accessors
    double getTotalScore()               const { return best_score_; }
    const std::vector<ScheduleEntry>& getSchedule() const { return schedule_; }

private:
    int total_time_;
    std::vector<Subject> subjects_;

    double best_score_ = 0.0;
    std::vector<ScheduleEntry> schedule_;

    // dp[i][t][f]
    // stored as flat vector: index = i*(T+1)*(F+1) + t*(F+1) + f
    std::vector<double> dp_;
    // back-tracking choice: 0=skip, 1=study, 2=break-then-study
    std::vector<int>    choice_;

    int idx(int i, int t, int f) const;

    double efficiency(int f) const;
    void   backtrack(int n);
    void   printBar(const std::string& label, double fraction, int width = 40) const;
};
