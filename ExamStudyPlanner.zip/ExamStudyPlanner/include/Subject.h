#pragma once
#include <string>
#include <iostream>
#include <iomanip>

/**
 * ============================================================
 *  Subject.h  —  Data model for a single exam subject
 * ============================================================
 *
 *  Each subject carries three planning-relevant attributes:
 *
 *  study_time     : how many 30-minute blocks are needed
 *                   (e.g. 4 units = 2 hours)
 *
 *  importance     : base marks/weightage score (1-100)
 *                   This is the CEILING score achievable at
 *                   zero fatigue (100 % efficiency).
 *
 *  fatigue_impact : mental drain imposed by this subject (1-10)
 *                   Added to the running fatigue counter once
 *                   the subject is studied.
 *                   1 = very easy  (revision, light reading)
 *                   5 = moderate   (standard theory subjects)
 *                   10= very hard  (heavy problem solving)
 */
class Subject {
public:
    std::string name;
    int         study_time;      // 30-min units required
    int         importance;      // base score (1-100)
    int         fatigue_impact;  // drain per session (1-10)

    Subject() = default;
    Subject(std::string name, int study_time, int importance, int fatigue_impact);

    void display() const;
};
