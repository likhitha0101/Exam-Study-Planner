#include "Planner.h"
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>

struct BT { int choice, prev_t, prev_f; };

Planner::Planner(int total_time_units) : total_time_(total_time_units) {}

void Planner::addSubject(const Subject& s) { subjects_.push_back(s); }

double Planner::efficiency(int f) const {
    double e = 1.0 - static_cast<double>(f) * FATIGUE_DECAY;
    return (e < 0.0) ? 0.0 : (e > 1.0 ? 1.0 : e);
}

int Planner::idx(int i, int t, int f) const {
    return i * (total_time_ + 1) * (MAX_FATIGUE + 1)
         + t * (MAX_FATIGUE + 1) + f;
}

void Planner::solve(bool allow_breaks) {
    const int N  = static_cast<int>(subjects_.size());
    const int T  = total_time_;
    const int F  = MAX_FATIGUE;
    const int SZ = (N + 1) * (T + 1) * (F + 1);

    dp_.assign(SZ, -1.0);
    std::vector<BT> bt(SZ, {0, 0, 0});

    // Base: 0 subjects consumed, 0 time, any fatigue → score 0
    for (int f = 0; f <= F; ++f)
        dp_[idx(0, 0, f)] = 0.0;

    auto tryUpdate = [&](int ni, int nt, int nf,
                         double cand, int ch, int pt, int pf) {
        if (nt > T || nf > F) return;
        if (cand > dp_[idx(ni, nt, nf)]) {
            dp_[idx(ni, nt, nf)] = cand;
            bt [idx(ni, nt, nf)] = {ch, pt, pf};
        }
    };

    for (int i = 0; i < N; ++i) {
        const Subject& sub = subjects_[i];
        const int s = sub.study_time;
        const int d = sub.fatigue_impact;

        for (int t = 0; t <= T; ++t) {
            for (int f = 0; f <= F; ++f) {
                double base = dp_[idx(i, t, f)];
                if (base < 0.0) continue;

                // SKIP
                tryUpdate(i+1, t, f, base, 0, t, f);

                // STUDY (costs s time, raises fatigue by d)
                if (t + s <= T) {
                    double score = sub.importance * efficiency(f);
                    int    nf    = std::min(f + d, F);
                    tryUpdate(i+1, t + s, nf, base + score, 1, t, f);
                }

                // BREAK then STUDY (costs BREAK_COST + s, lowers fatigue by BREAK_RECOVERY)
                if (allow_breaks && t + BREAK_COST + s <= T) {
                    int    f_rb  = std::max(0, f - BREAK_RECOVERY);
                    double score = sub.importance * efficiency(f_rb);
                    int    nf    = std::min(f_rb + d, F);
                    tryUpdate(i+1, t + BREAK_COST + s, nf,
                              base + score, 2, t, f);
                }
            }
        }
    }

    // Locate best terminal state
    best_score_ = 0.0;
    int best_t = 0, best_f = 0;
    for (int t = 0; t <= T; ++t)
        for (int f = 0; f <= F; ++f)
            if (dp_[idx(N, t, f)] > best_score_) {
                best_score_ = dp_[idx(N, t, f)];
                best_t = t; best_f = f;
            }

    // ── Back-track: collect which subjects were chosen ─────
    // We record (subject_index, used_break) pairs in DP order.
    struct Chosen { int subj_idx; bool had_break; };
    std::vector<Chosen> chosen;

    int cur_i = N, cur_t = best_t, cur_f = best_f;
    while (cur_i > 0) {
        BT b = bt[idx(cur_i, cur_t, cur_f)];
        if (b.choice == 1) chosen.push_back({cur_i - 1, false});
        else if (b.choice == 2) chosen.push_back({cur_i - 1, true});
        cur_i--;
        cur_t = b.prev_t;
        cur_f = b.prev_f;
    }
    std::reverse(chosen.begin(), chosen.end());

    // ── Rebuild schedule with consistent fatigue tracking ──
    schedule_.clear();
    int running_f = 0;   // fatigue starts at 0

    for (const auto& c : chosen) {
        const Subject& sub = subjects_[c.subj_idx];

        if (c.had_break) {
            // Insert break entry
            int f_after = std::max(0, running_f - BREAK_RECOVERY);
            ScheduleEntry brk;
            brk.label          = "-- Break --";
            brk.units          = BREAK_COST;
            brk.score          = 0.0;
            brk.fatigue_before = running_f;
            brk.fatigue_after  = f_after;
            schedule_.push_back(brk);
            running_f = f_after;
        }

        // Study entry
        ScheduleEntry e;
        e.label          = sub.name;
        e.units          = sub.study_time;
        e.score          = sub.importance * efficiency(running_f);
        e.fatigue_before = running_f;
        running_f        = std::min(running_f + sub.fatigue_impact, MAX_FATIGUE);
        e.fatigue_after  = running_f;
        schedule_.push_back(e);
    }
}

void Planner::printBar(const std::string& label, double fraction, int width) const {
    int filled = static_cast<int>(std::round(fraction * width));
    filled = std::max(0, std::min(width, filled));
    std::cout << "  " << std::left << std::setw(20) << label << " [";
    for (int i = 0; i < filled;         ++i) std::cout << "#";
    for (int i = filled; i < width; ++i) std::cout << ".";
    std::cout << "] "
              << std::fixed << std::setprecision(1)
              << fraction * 100.0 << "%\n";
}

void Planner::printResults() const {
    const std::string sep(65, '=');
    const std::string thin(65, '-');

    std::cout << "\n" << sep << "\n"
              << "       EXAM STUDY PLANNER  --  OPTIMAL SCHEDULE\n"
              << sep << "\n\n";

    std::cout << "REGISTERED SUBJECTS (" << subjects_.size() << ")\n"
              << thin << "\n";
    for (const auto& s : subjects_) { s.display(); std::cout << "\n"; }

    std::cout << "FATIGUE MODEL\n" << thin << "\n";
    std::cout << "  efficiency(f) = max(0, 1 - f x " << FATIGUE_DECAY << ")\n";
    for (int f = 0; f <= MAX_FATIGUE; f += 2) {
        std::ostringstream lbl; lbl << "fatigue=" << std::setw(2) << f;
        printBar(lbl.str(), efficiency(f));
    }
    std::cout << "\n";

    std::cout << "OPTIMAL STUDY SCHEDULE\n" << thin << "\n";
    std::cout << std::left
              << std::setw(22) << "Session"
              << std::setw(12) << "Time"
              << std::setw(14) << "Fatigue"
              << std::setw(10) << "Effic."
              << "Score\n" << thin << "\n";

    double running_score = 0.0;
    int    running_time  = 0;

    for (const auto& e : schedule_) {
        bool is_break = (e.label.find("Break") != std::string::npos);
        std::string time_str = std::to_string(e.units)
                             + "u (" + std::to_string(e.units * 30) + "m)";
        std::string fat_str  = std::to_string(e.fatigue_before)
                             + " -> " + std::to_string(e.fatigue_after);

        std::cout << std::left
                  << std::setw(22) << e.label
                  << std::setw(12) << time_str
                  << std::setw(14) << fat_str;

        if (is_break) {
            std::cout << std::setw(10) << "---" << "---";
        } else {
            std::ostringstream eff_str, sc_str;
            eff_str << std::fixed << std::setprecision(0)
                    << efficiency(e.fatigue_before) * 100.0 << "%";
            sc_str  << std::fixed << std::setprecision(1) << e.score;
            std::cout << std::setw(10) << eff_str.str() << sc_str.str();
            running_score += e.score;
        }
        running_time += e.units;
        std::cout << "\n";
    }

    std::cout << thin << "\n";
    std::string tot_str = std::to_string(running_time)
                        + "u (" + std::to_string(running_time * 30) + "m)";
    std::cout << std::left
              << std::setw(22) << "TOTAL"
              << std::setw(12) << tot_str
              << std::setw(38) << ""
              << std::fixed << std::setprecision(2) << running_score
              << "\n\n";

    std::cout << "TIME ALLOCATION (per subject)\n" << thin << "\n";
    for (const auto& e : schedule_) {
        if (e.label.find("Break") != std::string::npos) continue;
        double frac = total_time_ > 0
                    ? static_cast<double>(e.units) / total_time_ : 0.0;
        printBar(e.label, frac);
    }

    double max_possible = 0.0;
    for (const auto& s : subjects_) max_possible += s.importance;

    std::cout << "\n" << sep << "\n"
              << "  TOTAL ACHIEVABLE SCORE : "
              << std::fixed << std::setprecision(2) << best_score_
              << " / " << max_possible
              << "  ("
              << std::fixed << std::setprecision(1)
              << (max_possible > 0 ? best_score_ / max_possible * 100.0 : 0.0)
              << "% of max possible)\n"
              << sep << "\n\n";
}

void Planner::printDPTable() const {
    const int N    = static_cast<int>(subjects_.size());
    const int cols = std::min(total_time_, 12);

    std::cout << "\n--- DP TABLE SLICE (fatigue=0 plane) ---\n";
    std::cout << std::setw(4) << "i\\t";
    for (int t = 0; t <= cols; ++t) std::cout << std::setw(8) << t;
    std::cout << "\n";

    for (int i = 0; i <= N; ++i) {
        std::cout << std::setw(4) << i;
        for (int t = 0; t <= cols; ++t) {
            double v = dp_[idx(i, t, 0)];
            if (v < 0.0) std::cout << std::setw(8) << "-";
            else {
                std::ostringstream ss;
                ss << std::fixed << std::setprecision(1) << v;
                std::cout << std::setw(8) << ss.str();
            }
        }
        std::cout << "\n";
    }
    // Also print any-fatigue best per column
    std::cout << std::setw(4) << "best";
    for (int t = 0; t <= cols; ++t) {
        double best = -1.0;
        for (int f = 0; f <= MAX_FATIGUE; ++f)
            best = std::max(best, dp_[idx(N, t, f)]);
        if (best < 0.0) std::cout << std::setw(8) << "-";
        else {
            std::ostringstream ss;
            ss << std::fixed << std::setprecision(1) << best;
            std::cout << std::setw(8) << ss.str();
        }
    }
    std::cout << "\n-------------------------------------------\n\n";
}
