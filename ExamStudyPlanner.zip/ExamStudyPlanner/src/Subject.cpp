#include "Subject.h"

Subject::Subject(std::string n, int st, int imp, int fi)
    : name(std::move(n)), study_time(st), importance(imp), fatigue_impact(fi) {}

void Subject::display() const {
    std::cout << std::left
              << "  Name          : " << name          << "\n"
              << "  Study Time    : " << study_time    << " units ("
                                      << study_time * 30 << " min)\n"
              << "  Importance    : " << importance    << " marks\n"
              << "  Fatigue Impact: " << fatigue_impact << " / 10\n";
}
