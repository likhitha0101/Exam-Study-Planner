/**
 * ============================================================
 *  main.cpp  —  Exam Study Planner with Fatigue Optimization
 * ============================================================
 *
 *  Build:
 *    g++ -std=c++17 -O2 -Wall -Iinclude src/Subject.cpp \
 *        src/Planner.cpp src/main.cpp -o ExamStudyPlanner
 *
 *  Run (interactive):   ./ExamStudyPlanner
 *  Run (demo mode):     ./ExamStudyPlanner --demo
 */

#include "Subject.h"
#include "Planner.h"
#include <iostream>
#include <string>
#include <stdexcept>
#include <limits>

// ─────────────────────────────────────────────────────────────
//  Helper — safe integer input with bounds check
// ─────────────────────────────────────────────────────────────
static int readInt(const std::string& prompt, int lo, int hi) {
    int v;
    while (true) {
        std::cout << prompt;
        if (std::cin >> v && v >= lo && v <= hi) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return v;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Please enter a number between " << lo
                  << " and " << hi << ".\n";
    }
}

// ─────────────────────────────────────────────────────────────
//  demoMode  — pre-loaded scenario for quick testing
// ─────────────────────────────────────────────────────────────
static void demoMode() {
    std::cout << "\n========================================\n";
    std::cout << "          RUNNING IN DEMO MODE\n";
    std::cout << "========================================\n";
    std::cout << "Scenario: Engineering semester finals\n";
    std::cout << "Available time: 10 units (5 hours)\n";
    std::cout << "Subjects: 5  |  Breaks: enabled\n\n";

    Planner planner(10);   // 10 × 30 min = 5 hours

    planner.addSubject(Subject("Data Structures",  3, 90, 7));
    planner.addSubject(Subject("Mathematics",      4, 85, 8));
    planner.addSubject(Subject("Digital Circuits", 2, 70, 5));
    planner.addSubject(Subject("English",          1, 50, 2));
    planner.addSubject(Subject("OS Concepts",      3, 80, 6));

    planner.solve(/*allow_breaks=*/true);
    planner.printDPTable();
    planner.printResults();
}

// ─────────────────────────────────────────────────────────────
//  interactiveMode  — user enters subjects at runtime
// ─────────────────────────────────────────────────────────────
static void interactiveMode() {
    std::cout << "\n╔══════════════════════════════════════════════╗\n";
    std::cout <<   "║   EXAM STUDY PLANNER  —  Fatigue Optimizer  ║\n";
    std::cout <<   "╚══════════════════════════════════════════════╝\n\n";

    std::cout << "Each time unit = 30 minutes.\n\n";

    int totalUnits = readInt("Enter total available study time (units, 1-48): ", 1, 48);

    int numSubjects = readInt("Enter number of subjects (1-10): ", 1, 10);

    Planner planner(totalUnits);

    for (int i = 0; i < numSubjects; ++i) {
        std::cout << "\n── Subject " << (i + 1) << " ──────────────────────────\n";

        std::string name;
        std::cout << "  Name: ";
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        // handle possible leftover newline for the first subject
        if (i == 0) std::cin.clear();
        std::getline(std::cin, name);
        if (name.empty()) name = "Subject " + std::to_string(i + 1);

        int st  = readInt("  Study time required (units, 1-" +
                          std::to_string(totalUnits) + "): ", 1, totalUnits);
        int imp = readInt("  Importance / marks weightage (1-100): ", 1, 100);
        int fi  = readInt("  Fatigue impact (1=easy, 10=very hard): ", 1, 10);

        planner.addSubject(Subject(name, st, imp, fi));
    }

    int breaksChoice = readInt("\nAllow breaks to reset fatigue? (1=Yes / 0=No): ", 0, 1);
    bool allowBreaks = (breaksChoice == 1);

    std::cout << "\nSolving...\n";
    planner.solve(allowBreaks);
    planner.printResults();
}

// ─────────────────────────────────────────────────────────────
//  main
// ─────────────────────────────────────────────────────────────
int main(int argc, char* argv[]) {
    bool demo = (argc > 1 && std::string(argv[1]) == "--demo");

    if (demo) {
        demoMode();
    } else {
        interactiveMode();
    }

    return 0;
}
